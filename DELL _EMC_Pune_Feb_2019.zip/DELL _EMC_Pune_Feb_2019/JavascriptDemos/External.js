
 //"use strict"; // compiler option !    

 var msg = "Hello World !"; // loosely typed language !
 msg = 100;
 // console.log(typeof msg);
 // console.log(msg);

 var x; // declaration !
 //x = 1000;    // definition !
// z =2000;   // global !


// local scoped | function scoped !


//    function Test(){
//        var functionScopedVar = 100000;
//        console.log(functionScopedVar);
//    }
//    Test();


// var month = "January";
 

// function ChangeMonth(){
//     month = "February"; // month is global if above var month is commented 
//     console.log(month);
// }
// ChangeMonth();
// console.log(month);



// Variable hoisting !
 // z = 10000;
 // console.log(z);
 // var z;   // z is hoisted 


//     function ChangeMonth(){
//     month= "February"; // month is global if above var month is commented 
//     console.log(month);
//     var month;
// }

// ChangeMonth();
// console.log(month);

// Functions

//console.log(Square("10"));
// function Square(x){
//         return x * x;
// }
// console.log(Square(10));
// Function as an expression | Not hoisted !
// var Square = function(x){
//     console.log('Second Definition !')
//         return x * x;
// }
// console.log(typeof Square);

// Using a function object
// var Square = new Function("x","return x * x");
// console.log(Square(20));

// Arrays : 

var cars = ["BMW","FERRARI","AUDI",10];

// Array Object

var moreCars = new Array("TATA","MARUTI","MAHINDRA")


// for
// for - in
// for(var c in moreCars){
//     console.log(moreCars[c]); // index
// }

// for-of  [ES 6]
// for(var c of moreCars){
//     console.log(c); // element
// }
// for-each
// cars.forEach(function(){
//         console.log(car);    
// });

// console.log('Program ended..');

//Functions that return a function;

// function Outer(){      
//     var x = 100;
//     console.log('Outer Function called , x :  ' + x);
//     return function(){
//         console.log('Inner Function called ,x : ' + x); // x is a closure variable !
//     }
// }
// var innerFunc = Outer();
// innerFunc();


/* Recursive !*/

// function factorial(x){
//     if(x<=1)
//         return 1;
//     return x * factorial(x-1);
// }

// console.log(factorial(4));


// IIFE - Immediately invocable function expression !


//  var returnedVal = (function(){
//         return 'IIFE !!';
//  })();
//  console.log(returnedVal);

// var result = (function(x,y){
//         return x + y;
// })(10,20);

// console.log(result);
   

// setTimeout(function(){
//         console.log('Printed after 2 seconds !');
// },2000);
// console.log('Program Ended !');


// Operators

var x = "10",y = 20,z = 30;
console.log(x + y + z); // string appended 102030
console.log(y + z + x); // "5010"

var a = "10ss";
var b = 10;

// if(a == b){   //compares the value !
//     console.log('a equals b !'); 
// }

// if(a === b){
//     console.log('a equals b with same type  !'); 
// }
console.log((a == b) ? " Equal with values":"Not Equal !");
console.log(eval("10*3"));

//var convertAToNumber = +(a);   // will return NaN when characters are added !
// var convertAToNumber = parseInt(a);
//console.log(typeof convertAToNumber);


var aNullVar = null;
var undefinedVar;
var x = 100;

var mustHaveAValue;

// if(!aNullVar){
//     mustHaveAValue = x;
// }

mustHaveAValue = aNullVar || x; // short-hand or short-circuiting
 







