function Add(x,y){
    return x + y;
}
function Product(x,y){
    return x * y;
}


