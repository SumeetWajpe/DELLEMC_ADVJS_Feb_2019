
var calculator;// = {divide:function(x,y){ return x/y}};

var mathModule = (function(theObject){

   theObject.Add = function(x,y) {
  
        return x + y;
}
theObject.Multiply = function  (x,y) {
    return x * y;
}
var PI = 3.14;
return theObject;
})(calculator || {})