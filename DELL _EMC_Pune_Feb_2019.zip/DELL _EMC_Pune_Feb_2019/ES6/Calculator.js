// import {Add,Product} from './Math.js'; // selective import
import * as Calc from './Math.js';

console.log('The addition is : ' + Calc.Add(20,30));